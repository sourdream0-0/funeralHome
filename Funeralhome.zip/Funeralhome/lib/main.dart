import 'package:flutter/material.dart';
import 'package:start_prj_3/authControl.dart';
import 'userEditForm.dart';
import 'orderAddForm.dart';
import 'orderEditForm.dart';
import 'clientAddForm.dart';
import 'clientEditForm.dart';
import 'ordersList.dart';
import 'clientList.dart';
import 'usersDataControl.dart';
import 'MainScreen.dart';
import 'MainScreen2.dart';
import 'userRegisterForm.dart';
import 'menu.dart';

void main() {

  usersDataControl dc = new usersDataControl();
  authControl ac = new authControl();
  ac.dataInit();
  dc.dataInit();

  runApp(MaterialApp(
    initialRoute: '/',
    routes: {
      '/': (BuildContext context) => MainScreen(),
      '/2': (BuildContext context) => MainScreen2(),
      '/elementForm': (BuildContext context) => userRegisterForm(),
      '/elementForm1': (BuildContext context) => userEditForm(),
      '/menu': (BuildContext context) => menu(),
      '/elementListclients': (BuildContext context) => clientsList(),
      '/elementFormclients': (BuildContext context) => clientAddForm(),
    },
    onGenerateRoute: (routeSettings){
      var path=[];
      String rname = routeSettings.name.toString();
      path = rname.split('/');
      if (path[1]=='elementList2'){
        return new MaterialPageRoute(
          builder: (context)=>new ordersList(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='elementForm'){
        return new MaterialPageRoute(
          builder: (context)=>new userRegisterForm(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='elementForm1'){
        return new MaterialPageRoute(
          builder: (context)=>new userEditForm(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='elementForm2'){
        return new MaterialPageRoute(
          builder: (context)=>new orderAddForm(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='menu'){
        return new MaterialPageRoute(
          builder: (context)=>new menu(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='elementListclients'){
        return new MaterialPageRoute(
          builder: (context)=>new clientsList(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='elementFormclients'){
        return new MaterialPageRoute(
          builder: (context)=>new clientAddForm(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='elementFormclientsEdit'){
        return new MaterialPageRoute(
          builder: (context)=>new clientEditForm(value:path[2]),
          settings: routeSettings,
        );
      };
      if (path[1]=='elementForm2Edit'){
        return new MaterialPageRoute(
          builder: (context)=>new orderEditForm(value:path[2]),
          settings: routeSettings,
        );
      };
    },

  ));
}