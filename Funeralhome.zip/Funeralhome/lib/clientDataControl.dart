import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class clientsDataControl{
  static const dataKey = 'clientsData';
  static var _clients=[];
  static int cid=19;
  static int status=0;

  dataInit() async{
    if (status == 0) {
      _clients = json.decode(await _getData());
    }

    status=1;
  }

  GetItem(int i){
    return _clients[i];
  }

  GetCID(){
    return cid;
  }

  IncreaseCID(){
    cid++;
  }

  GetItemByUID(int uid){
    for (int i=0; i<_clients.length; i++){
      if (_clients[i]["uid"] == uid)
        return _clients[i];
    }
  }

  GetItemByCID(int uid){
    for (int i=0; i<_clients.length; i++){
      if (_clients[i]["cid"] == uid)
        return _clients[i];
    }
  }

  Future deleteItem(int cid) async{
    _clients.removeWhere((item) => item["cid"] == cid);
  }

  int getLength(){
    return _clients.length;
  }

  String checkUser (String login, String pasw){
    int i;
    for (i=0; i<_clients.length; i++){
      if (_clients[i]["login"]==login && _clients[i]["pasw"]==pasw) return _clients[i]["login"];
    }
    return "";
  }

  Future addItem(int cid, int uid, String FIO, String phoneNumber, String email, String info) async{
    Map Item={"cid":cid, "uid":uid, "FIO":FIO, "phoneNumber":phoneNumber, "e-mail":email, "information":info};
    _clients.add(Item);
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(dataKey, jsonEncode(_clients));
  }

  Future<String> _getData() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(dataKey) ?? "[]";
  }

  void saveItem(int cid, String FIO, String phoneNumber, String email, String info){
    Map Item={"FIO":FIO, "phoneNumber":phoneNumber, "e-mail":email};
    GetItemByCID(cid)["FIO"]=FIO;
    GetItemByCID(cid)["phoneNumber"]=phoneNumber;
    GetItemByCID(cid)["e-mail"]=email;
    GetItemByCID(cid)["information"]=info;
  }

  void printData(){
    print("");
    print("clients:");
    print(_clients);
  }

  List<String> returnFIOsOfclients(){
    List<String> fioList = _clients.map((item) => item['FIO'] as String).toList();
    return (fioList);
  }

  Future getStringInfo(String Key) async{
    final prefs = await SharedPreferences.getInstance();
    prefs.getString(Key) ?? "";
  }

  Future setStringInfo(String Key, String Value) async{
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(Key, Value);
  }

}
