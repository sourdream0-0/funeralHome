import 'package:flutter/material.dart';
import 'usersDataControl.dart';
import 'ordersDataControl.dart';
import 'clientDataControl.dart';
import 'dart:async';

class orderEditForm extends StatefulWidget {
  @override
  var _value;

  orderEditForm({var value}):_value = value;

  _elementFormState createState() => _elementFormState();
  getValue(){
    return _value;
  }
}

class _elementFormState extends State<orderEditForm> {
  var uid;
  usersDataControl dc = new usersDataControl();
  ordersDataControl dc2 = new ordersDataControl();
  clientsDataControl dcC = new clientsDataControl();
  var typeOfEditing = "";

  String? selectedclient;
  List<String> listOfclients = [];

  String? selectedProduct;
  List<String> listOfProducts = ['Ordering a coffin', 'Memorial dinner', 'Funeral service of a person', 'Making a monument'];

  List<String> statusOptions = ['Agreement', 'Realization', 'Testing', 'Bug fixes','Transfer to client'];
  String? selectedStatus;

  final TextEditingController clientController = TextEditingController();
  final TextEditingController productController = TextEditingController();
  final TextEditingController quantityController = TextEditingController();
  final TextEditingController statusController = TextEditingController();
  DateTime? selectedDate; // Добавлено для хранения выбранной даты

  void initState(){
    super.initState();

    dcC = clientsDataControl(); // Создание экземпляра dcC

    if (widget._value != null){
      var item = dc2.GetItemByTID(int.parse(widget._value));
      quantityController.text = item['quantity'];
      selectedDate = DateTime.parse(item['deadline']); // Установка выбранной даты
      selectedStatus = item['status'];
      selectedclient = item['client'];
      selectedProduct = item['product'];
      typeOfEditing = "save";
    } else {
      typeOfEditing = "new";
    }

    initializeA(); // Вызов метода initializeA() для заполнения списка listOfclients
  }

  void initializeA() {
    listOfclients = dcC.returnFIOsOfclients(); // Присваивание значений из dcC.returnFIOsOfclients()
  }

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit order"),
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: _buildContent(),
      ),
    );
  }

  Widget _buildContent(){
    return Form(
      key: _formKey,
      child: Column(
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: DropdownButtonFormField<String>(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.person),
                hintText: "Client",
              ),
              value: selectedclient,
              onChanged: (String? newValue) {
                setState(() {
                  selectedclient = newValue;
                });
              },
              items: listOfclients.map((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
              validator: (value) {
                print(listOfclients);
                if (listOfclients.isEmpty){
                  return "There are no clients registered. Before creating order you must register at least one client";
                }
                if (value == null || value.isEmpty){
                  return "Client is empty";
                }
                return null;
              },
            ),
          ),

          SizedBox(height: 10),

          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.production_quantity_limits),
              hintText: "Product",
            ),
            value: selectedProduct,
            onChanged: (String? newValue) {
              setState(() {
                selectedProduct = newValue;
              });
            },
            items: listOfProducts.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            validator: (value){
              if (value == null || value.isEmpty) {
                return "Product is empty";
              }
              return null;
            },
          ),

          SizedBox(height: 10),

          TextFormField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.numbers),
              hintText: "Price",
            ),
            controller: quantityController,
            keyboardType: TextInputType.number,
            validator: (value){
              if (value == null || value.isEmpty) {
                return "Price is empty";
              }
              final intValue = int.tryParse(value);
              if (intValue == null || intValue < 1 || intValue > 1000) {
                return "Price must be an integer between 1 and 1000";
              }
              return null;
            },
          ),

          SizedBox(height: 10),

          InkWell(
            onTap: () {
              _selectDate(context); // Открывает диалог выбора даты
            },
            child: InputDecorator(
              decoration: InputDecoration(
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.date_range),
                hintText: "Deadline",
              ),
              child: Text(selectedDate != null
                  ? "${selectedDate!.day}-${selectedDate!.month}-${selectedDate!.year}"
                  : "Select date"), // Отображает выбранную дату или текст "Select date"
            ),
          ),

          SizedBox(height: 10),

          DropdownButtonFormField<String>(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.mode),
              hintText: "Status",
            ),
            value: selectedStatus,
            onChanged: (String? newValue) {
              setState(() {
                selectedStatus = newValue;
              });
            },
            items: statusOptions.map((String value) {
              return DropdownMenuItem<String>(
                value: value,
                child: Text(value),
              );
            }).toList(),
            validator: (value){
              if (value == null || value.isEmpty) {
                return "Status is empty";
              }
              return null;
            },
          ),

          SizedBox(height: 10),

          ElevatedButton(
            child: Text(typeOfEditing),
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                _btnPress();
              }
            },
          ),
        ],
      ),
    );
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime.now().add(Duration(days: 1)), // Задайте первую доступную дату - завтрашнюю дату
      lastDate: DateTime(2100),
    );
    if (picked != null && picked != selectedDate) {
      setState(() {
        selectedDate = picked;
      });
    }
  }

  void _btn2Press(){
    dc2.deleteItem(int.parse(widget._value));
    uid = dc.GetCurrentUID();
    Navigator.pushNamed(context, "/elementList2/$uid");
  }

  void _btnPress(){
    dc2.saveItem(
      int.parse(widget._value),
      selectedclient ?? '',
      selectedProduct ?? '',
      quantityController.text,
      selectedDate?.toIso8601String() ?? '', // Сохраняет выбранную дату в формате ISO 8601
      selectedStatus ?? '',
    );
    dc2.printData();
    uid = dc.GetCurrentUID();
    Navigator.pushNamed(context, "/elementList2/$uid");
  }
}
