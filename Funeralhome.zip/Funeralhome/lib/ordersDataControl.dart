import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class ordersDataControl{
  static const dataKey = 'ordersData';
  static var _orders=[];
  static int tid=1;
  static int status=0;

  dataInit() async{
    if (status == 0) {
      _orders = json.decode(await _getData());
    }
    status=1;
  }

  GetItem(int i){
    return _orders[i];
  }

  GetTID(){
    return tid;
  }

  IncreaseTID(){
    tid++;
  }

  GetItemByUID(int uid){
    for (int i=0; i<_orders.length; i++){
      if (_orders[i]["uid"] == uid)
        return _orders[i];
    }
  }

  GetItemByTID(int tid){
    for (int i=0; i<_orders.length; i++){
      if (_orders[i]["tid"] == tid)
        return _orders[i];
    }
  }

  Future deleteItem(int tid) async{
    _orders.removeWhere((item) => item["tid"] == tid);
  }

  int getLength(){
    return _orders.length;
  }

  Future addItem(int tid, int uid, String customer, String product, String quantity, String deadline, String status) async{
    Map Item={"tid":tid, "uid":uid, "client":customer, "product":product, "quantity":quantity, "deadline":deadline, "status":status};
    _orders.add(Item);
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(dataKey, jsonEncode(_orders));
  }

  Future<String> _getData() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(dataKey) ?? "[]";
  }

  void saveItem(int tid, String customer, String product, String quantity, String deadline, String status){
    Map Item={"client":customer, "product":product, "quantity":quantity, "deadline":deadline, "status":status};
    GetItemByTID(tid)["client"]=customer;
    GetItemByTID(tid)["product"]=product;
    GetItemByTID(tid)["quantity"]=quantity;
    GetItemByTID(tid)["deadline"]=deadline;
    GetItemByTID(tid)["status"]=status;
  }

  void printData(){
    print("");
    print("orders:");
    print(_orders);
  }

  Future getStringInfo(String Key) async{
    final prefs = await SharedPreferences.getInstance();
    prefs.getString(Key) ?? "";
  }

  Future setStringInfo(String Key, String Value) async{
    final prefs = await SharedPreferences.getInstance();
    prefs.setString(Key, Value);
  }

}
