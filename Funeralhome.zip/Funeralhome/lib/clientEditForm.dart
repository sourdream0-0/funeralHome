import 'package:flutter/material.dart';
import 'usersDataControl.dart';
import 'clientDataControl.dart';

class clientEditForm extends StatefulWidget {
  @override
  var _value;

  clientEditForm({var value}):_value = value;

  _elementFormState createState() => _elementFormState();
  getValue(){
    return _value;
  }

}


bool isValidPhoneNumber(String phoneNumber) {
  final RegExp phoneRegex = RegExp(r'^7-9\d{2}-\d{3}-\d{2}-\d{2}$');
  return phoneRegex.hasMatch(phoneNumber);
}

bool isValidEmail(String email) {
  final RegExp emailRegex = RegExp(r'^[\w-]+(\.[\w-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*(\.[a-zA-Z]{2,})$');
  return emailRegex.hasMatch(email);
}

bool isAlphaWithSpaces(String value) {
  final alphaRegex = RegExp(r'^[a-zA-Z\s]+$');
  return alphaRegex.hasMatch(value);
}


class _elementFormState extends State<clientEditForm> {
  var uid;
  usersDataControl dc = new usersDataControl();
  clientsDataControl dcC = new clientsDataControl();
  var typeOfEditing = "";

  final TextEditingController loginController = TextEditingController();
  final TextEditingController paswController = TextEditingController();
  final TextEditingController subjectController = TextEditingController();
  final TextEditingController infoController = TextEditingController();
  void initState(){
    // print("_value = ${widget._value}");
    super.initState();

    if (widget._value!=null){
      // loginController.text =
      loginController.text = dcC.GetItemByCID(int.parse(widget._value))['FIO'];
      paswController.text = dcC.GetItemByCID(int.parse(widget._value))['phoneNumber'];
      subjectController.text = dcC.GetItemByCID(int.parse(widget._value))['e-mail'];
      infoController.text = dcC.GetItemByCID(int.parse(widget._value))['information'];
      typeOfEditing = "Save";
    }
    else{
      loginController.text='';
      typeOfEditing = "New";
    }
  }
  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text("Edit client"),
      ),
      body: Padding(
        padding: EdgeInsets.all(15),
        child: _buildContent(),
      ),
    );
  }
  Widget _buildContent() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          TextFormField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.person),
              hintText: "FIO",
            ),
            controller: loginController,
            validator: (value) {
              if (value == null || value.isEmpty) {
                return "FIO is empty";
              }
              if (!isAlphaWithSpaces(value)) {
                return "FIO must contain only english letters and spaces";
              }
              if (value.length < 10) {
                return "FIO cannot be less than 10 characters";
              }
              return null;
            },
          ),
          SizedBox(height: 10),

          TextFormField(
            // obscureText: true,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.phone),
              hintText: "Phone number",
            ),
            controller: paswController,
            validator: (value){
              if (value == null || value.isEmpty) {
                return "Phone number is empty";
              }
              if (value.length < 11){
                return "The phone number cannot be less than 11 characters";
              }
              return null;
            },
          ),

          SizedBox(height: 10),

          TextFormField(
            // obscureText: true,
            decoration: InputDecoration(
              border: OutlineInputBorder(),
              prefixIcon: Icon(Icons.email),
              hintText: "E-mail",
            ),
            controller: subjectController,
            validator: (value){
              if (value == null || value.isEmpty) {
                return "E-mail is empty";
              }
              if (value.length < 10){
                return "E-mail cannot be less than 10 characters";
              }
              return null;
            },
          ),

          SizedBox(height: 10),

          TextFormField(
            minLines: 6,
            maxLines: null,
            keyboardType: TextInputType.multiline,
            decoration: InputDecoration(
              alignLabelWithHint: true,
              border: OutlineInputBorder(),
              labelText: 'Additional information about client',
            ),
            controller: infoController,
          ),

          SizedBox(height: 10),

          ElevatedButton(
            child: Text(typeOfEditing),
            onPressed: _btnPress,
          ),
          SizedBox(height: 10),
          ElevatedButton(
            // selectionColor: Colors.red ,
              child: Text("Delete", ),
              onPressed: _btn2Press,
              style: ElevatedButton.styleFrom(
                primary: Colors.red[900],)
          ),
        ],
      ),
    );
  }

  void _btn2Press(){
    // print(widget._value);
    dcC.deleteItem(int.parse(widget._value));
    uid = dc.GetCurrentUID();
    Navigator.pushNamed(context, "/elementListclients/$uid");
  }

  void _btnPress() {
    if (_formKey.currentState!.validate()) {
      if (!isValidPhoneNumber(paswController.text)) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("Invalid Phone Number"),
              content: Text("Please enter a valid phone number in the format: 7-9XX-XXX-XX-XX"),
              actions: [
                TextButton(
                  child: Text("OK"),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
        return;
      }

      if (!isValidEmail(subjectController.text)) {
        showDialog(
          context: context,
          builder: (BuildContext context) {
            return AlertDialog(
              title: Text("Invalid E-mail"),
              content: Text("Please enter a valid e-mail address"),
              actions: [
                TextButton(
                  child: Text("OK"),
                  onPressed: () {
                    Navigator.of(context).pop();
                  },
                ),
              ],
            );
          },
        );
        return;
      }

      // Proceed with saving the data
      if (typeOfEditing == "New") {
        dc.saveItem(
          int.parse(widget._value),
          loginController.text,
          paswController.text,
          subjectController.text,
          infoController.text,
        );
      } else if (typeOfEditing == "Save") {
        dcC.saveItem(
          int.parse(widget._value),
          loginController.text,
          paswController.text,
          subjectController.text,
          infoController.text,
        );
      }

      dcC.printData();
      uid = dc.GetCurrentUID();
      Navigator.pushNamed(context, "/elementListclients/$uid");
    }
  }

}








//