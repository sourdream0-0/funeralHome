package com.example.start_prj_7

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
